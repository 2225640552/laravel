<!DOCTYPE html>
<html lang="en">
<head>
	<script src="/js/jquery-3.1.1.min.js"></script>
	<meta charset="UTF-8">
	<title>展示</title>
	<style>
		ul li{list-style: none; float: left; margin-left: 20px;}
		a{text-decoration: none;}
	</style>
</head>
<body>
	<tr>
			<td>
				<form action="create" method="post">
					<input type="radio" value="1" name="is_hot" >热门产品
					<input type="radio" value="0" name="is_hot">普通产品
					<input type="radio" value="1" name="is_ja">上架中
					<input type="radio" value="0" name="is_ja">未上架
					<input type="submit" id="btn" value="搜索">
				</form>	
			</td>
		</tr>
	<table border="1" cellspacing='0'>
		<thead>
				<tr>
					<td>名称</td>
					<td>分类</td>
					<td>描述</td>
					<td>是否热销</td>
					<td>是否上架</td>
					<td>操作</td>
				</tr>
		</thead>
		<tbody>
				<?php foreach($arr as $v){ ?>
				<tr>
					<td name="{{$v->goods_id}}"><span id="cbd">{{$v->goods_name}}</span></td>
					<td>{{$v->goods_cate}}</td>
					<td>{{$v->goods_count}}</td>
					<td align="center">
						<?php if($v->is_hot==1){ ?>
							<input type="button" value="是" name="{{$v->goods_id}}" id="is_hot">
						<?php }else{ ?>
							<input type="button" value="否" name="{{$v->goods_id}}" id="is_hot">
						<?php } ?>
					</td>
					<td align="center">
						<?php if($v->is_ja==1){ ?>
							<input type="button" value="是" name="{{$v->goods_id}}" id="is_ja">
						<?php }else{ ?>
							<input type="button" value="否" name="{{$v->goods_id}}" id="is_ja">
						<?php } ?>
					</td>
					<td><a href="javascript:;" onclick="del({{$v->goods_id}})">[删除]</a>
						<a href="read?id={{$v->goods_id}}">[修改]</a></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>
	{{$arr->appends(['is_hot' => $is_hot,'is_ja'=>$is_ja])->links()}}
</body>
</html>
			<!-- <script>
				$('#btn').click(function(){
						var data=$('#form').serialize();
						$.ajax({
							url:'tab',
							data:data,
							type:'post',
							success:function(msg){
								var str='';
								// $.each(arr,function(i,v){
								// 	str+="<tr>"
								// 		+"<td>"+v.goods_name+"</td>"
								// 		+"<td>"+v.goods_cate+"</td>"
								// 		+"<td>"+v.goods_count+"</td>"
								// 		+"<td>"+<>+
								// 		"</tr>"
								// })		
								$('table').html(msg);					}
						
					});
				});
			</script> -->
<script>
	$('#cbd').click(function(){
		var ad = $('#cbd').text();
		var id = $('#cbd').parent().attr('name');
		//alert(id);
		$('#cbd').parent().html("<input type='text' value="+ad+" name='goods_name'>");
		 $("[name='goods_name']").blur(function(){
			var add = $("[name='goods_name']").val();
			$.ajax({
				url:'alt',
				data:{'goods_id':id,'goods_name':add},
				type:'post',
				success:function(msg){
						if(msg==1){
							window.location.reload();

						}else{
							$('#cbd').parent().html("<span>"+{{$v->goods_name +"</span>");
						}
				}
			});

		});
		
	});

	function del(id){
		$.ajax({
			url:'delete',
			data:'id='+id,
			type:'post',
			success:function(msg){
				if(msg==1){
					alert("删除成功");
					window.location.reload();
				}else{
					alert("删除失败");
				}
			}
		});
	}
	
	$(document).on('click','#is_hot',function(){
		var is = $(this);
		var ck = $(this).val();
		//alert(ck);
		var id = is.attr('name');
		if(ck=='是'){
			var snk = 0;
		}else{
			var snk = 1;
		}

		$.ajax({
			url:'ajd',
			data:{'goods_id':id,'is_hot':snk},
			type:'post',
			success:function(msg){
				if(msg==1){
					is.val('是');
				}else if(msg==0){
					is.val('否');
				}else{
					alert('修改失败');
				}
			}
		});
	});
	

	$(document).on('click','#is_ja',function(){
		var is = $(this);
		var ck = $(this).val();
		//alert(ck);
		var id = is.attr('name');
		if(ck=='是'){
			var snk = 0;
		}else{
			var snk = 1;
		}

		$.ajax({
			url:'skr',
			data:{'goods_id':id,'is_ja':snk},
			type:'post',
			success:function(msg){
				if(msg==1){
					is.val('是');
				}else if(msg==0){
					is.val('否');
				}else{
					alert('修改失败');
				}
			}
		});
	});
	
	
</script>