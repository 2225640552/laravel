<!DOCTYPE html>
<html lang="en">
<head>
	<script src="/js/jquery-3.1.1.min.js"></script>
	<meta charset="UTF-8">
	<title>添加</title>
</head>
<body>
	<form action="caps" method="post">
		<input type="hidden" value="{{$arr->goods_id}}" name="goods_id">
		<table>
			<tr>
				<td>名称</td>
				<td><input type="text" name="goods_name" value="{{$arr->goods_name}}"></td>
			</tr>
			<tr>
				<td>分类</td>
				<td>
					<select name="goods_cate" id="">
						@foreach($arrCate as $v)
	
							<option @if($arr->goods_cate==$v->cate_id) selected @endif value="{{$v->cate_id}}">{{$v->cate_name}}</option>
							
						@endforeach
					</select>
				</td>
			</tr>
			<tr>
				<td>描述</td>
				<td><textarea name="goods_count" id="" cols="30" rows="10">{{$arr->goods_count}}</textarea></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="确定" ></td>
			</tr>
		</table>
	</form>
</body>
</html>