<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\models\Goods;

class Admin extends Controller
{
   public function show(Request $request)
   {
   	 // 	$sql = "insert into shop_user values(1,'赵四','58','男')";
   		// $bol = Db::insert($sql);
   		// print_r($bol);
   		// $sql = "select *from shop_user";
   		// $arr = Db::select($sql);
   		// foreach($arr as $v){
   		// 	echo $v->u_name;
   		// 	echo $v->u_sex;
   		// }
   		// $sql = "update shop_user set u_name='张三' where u_id=1";
   		// $bol = Db::update($sql);
   		$sql = "delete from shop_user where u_id=1";
   		$bol = Db::delete($sql);
   		print_r($bol);

   }
   public function index()
   {
	   	$sql = "select *from shop_cate";
	   	$arr = Db::select($sql);
	   	return view('index',['arr'=>$arr]);
   }
   //添加
   public function save(Request $request)
   {
	   	$data = $request->input();
	   	$bol = Goods::create($data);
	   	return $bol;
   }
   //查询，分页
   public function create(Request $request)
   {
         $is_hot = $request->input('is_hot');
         $is_ja = $request->input('is_ja');
         $where=['is_hot'=>$is_hot,'is_ja'=>$is_ja];
         //var_dump($where);
         if($where['is_ja']!=''||$where['is_hot']!=''){
            $arr = Goods::where($where)->paginate(1);
         }else{
            $arr = Goods::paginate(1);
         }
   		return  view('create',['arr'=>$arr,'is_hot'=>$is_hot,'is_ja'=>$is_ja]);
   }
   //删除
   public function delete(Request $request)
   {
   		$id = $request->input('id');
   		$res = Goods::destroy($id);
   		if($res){
   			return 1;
   		}else{
   			return 0;
   		}
   }
   //修改
   public function ajd(Request $request)
   {
   		$is_hot = $request->input('is_hot');
   		$id = $request->input('goods_id');
   		$res = Goods::where('goods_id', $id)
      			->update(['is_hot' => $is_hot]);
   		if($res){
   			return $is_hot;
   		}else{
   			return 2;
   		}
   }

   public function skr(Request $request)
   {
   		$is_ja = $request->input('is_ja');
   		$id = $request->input('goods_id');
   		$sql = "update shop_goods set is_ja=$is_ja where goods_id=$id";
   		$res = Db::update($sql);
   		if($res){
   			return $is_ja;
   		}else{
   			return 2;
   		}
   }

   public function read(Request $request){
   	$id = $request->input('id');
   	$sql = "select *from shop_cate";
	$arrCate = Db::select($sql);
   	$arr = Goods::where('goods_id','=',$id)
   		->first();
   	//var_dump($arr);die;
   	return view('read',['arr'=>$arr,'arrCate'=>$arrCate]);
   }

   public function caps(Request $request){
   		$arr = $request->input();
   		//var_dump($arr);die;
   		$res = Goods::where('goods_id',$arr['goods_id'])->update($arr);
   		if($res){
   			echo "修改成功";
   			return redirect('create');
   		}else{
   			echo "修改失败";
   		}

   }

   // public function tab(Request $request){
        
   // }
   // 
   public function alt(Request $request){
        $data = $request->input();
        $res = Goods::where('goods_id',$data['goods_id'])->update($data);
        if($res){
         return 1;
        }else{
         return 0;
        }
    }
}
