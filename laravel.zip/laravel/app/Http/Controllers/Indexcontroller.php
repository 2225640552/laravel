<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\Goods;
use App\models\Cate;
use App\models\User;
use App\models\Car;
use App\models\order;
use App\models\Detail;
use App\models\Address;
use App\models\Address_order;

class Indexcontroller extends Controller
{
    public function index(){
    	$arr = Goods::where('tell',1)->get();
    	$data = Goods::paginate(8);
    	
    	//var_dump($data);
    	return view('index',['arr'=>$arr,'data'=>$data]);
    }

    public function pgup(Request $request){
    	$pages =intval(Goods::count()/8);
    	//var_dump($pages);
    	$data = Goods::paginate(8);
    	$res = [
    		'pages'=>$pages,
    		'data'=>$data
    	];
    	//var_dump($res);
    	return $res;
    }

    public function user(){
    	return view('user');
    }

    public function allshops(){
    	$data = Cate::all();
    	//$arr=Goods::get();
    	return view('shop/allshops',['data'=>$data]);

    }

    public function shi(Request $request){
    	$id = $request->input('id');
    	$ad = $request->input('ad');
    	$daat = Cate::get();
    
    	//$ids = $this->test($daat,$id);
    	//var_dump($ids);die;
    	if($id==0){
    		$arr=Goods::orderBy($ad,'desc')->paginate(2);
    		//dump($arr);
    		$pages = ceil(Goods::count()/2);
    		$error=[
	    			'status'=>1,
	    			'msg'=>$arr,
	    			'page'=>$pages
	    		];
	    		return $error;
    	}else{
    		$arr = Goods::where('cat_id',$id)->orderBy($ad,'desc')->paginate(2);
	    	$pages = ceil(Goods::where('cat_id',$id)->count()/2);
	    	if(!empty($arr)){
	    		$error=[
	    			'status'=>1,
	    			'msg'=>$arr,
	    			'page'=>$pages
	    		];
	    		return $error;
	    	}else{
	    		$error=[
	    			'status'=>0,
	    			'msg'=>'该分类下暂无商品'
	    		];
	    		return $error;
	    	}
    	}
    	
    }

    public function shopcontent(Request $request){
        $id = $request->input('id');
        $arr = Goods::where('goods_id',$id)->first();
        $tel = session('tel');
         $use = User::where('tel',$tel)->first();
         
        $add = Car::where('user_id',$use['u_id'])->get();
        $where=[
            'user_id'=>$use['u_id'],
            'status'=>1
        ];
        if($add){
            $add = Car::where($where)->get()->toArray();
        }else{
            $add = Car::where($where)->get();
        }
        $num = Array_column($add,'goods_num');
        $as = Array_sum($num);
    	return view('shop/shopcontent',['arr'=>$arr,'num'=>$as]);
    } 

    public function content(Request $request){
        $id = $request->input('id');
         $asd = Goods::where('goods_id',$id)->first();
        $goods_name = $asd['goods_name'];
        if(!empty(session('tel'))){//判断是否登录
            $wh=[
                'goods_id'=>$id,
                'is_best'=>1
            ];
            $arr = Goods::where($wh)->first();
            if(!empty($arr)){

            
            if($arr['goods_number']>0){//判断库存是否充足
                $goods_id=$arr['goods_id'];
                $tel = session('tel');
                $use = User::where('tel',$tel)->first();
                $where=[
                    'user_id'=>$use['u_id'],
                    'goods_id'=>$goods_id
                ];
                $car = Car::where($where)->first();

                if(!empty($car)){//判断该商品是否存在于该用户购物车中
                    if($car['goods_num']>=$arr['goods_number']){
                        $error = [
                            'status'=>0,
                            'msg'=>'该商品库存不足'
                        ];
                        return $error;
                    }else{
                        $data=[
                        'goods_id'=>$goods_id,
                        'user_id'=>$use['u_id'],
                        'goods_num'=>$car['goods_num']+1,
                        'goods_name'=>$goods_name,
                        'status'=>1
                        ]; 
                        $res = Car::where('car_id',$car['car_id'])->update($data);
                    }
                    
                }else{
                    $data=[
                    'goods_id'=>$goods_id,
                    'user_id'=>$use['u_id'],
                    'goods_num'=>1,
                    'goods_name'=>$goods_name,
                    'status'=>1
                    ];
                    $res = Car::insert($data); 
                }
                if($res){
                    $error = [
                        'status'=>2,
                        'msg'=>'添加成功'
                    ];
                    return $error;
                }else{
                    $error = [
                        'status'=>0,
                        'msg'=>'发生系统错误请联系管理员'
                    ];
                    return $error;
                }
                
                
            }else{
                $error = [
                    'status'=>0,
                    'msg'=>'抱歉该商品库存不足'
                ];
                return $error;
            }
            }else{
                $error = [
                    'status'=>0,
                    'msg'=>'该商品已下架'
                ];
                return $error;
            }
        }else{
            $error = [
                'status'=>1,
                'msg'=>'请登录后再添加购物车'
            ];
            return $error;
        }
        

        

    }

    public function shopse(){
        if(!empty(session('tel'))){
            $error = [
                'status'=>1,
                'msg'=>''
            ];
            return $error;
        }else{
            $error = [
                'status'=>0,
                'msg'=>'请登录后再进入购物车'
            ];
            return $error;
        }
    }

    public function shopcart(){
        $tel = session('tel');
        $use = User::where('tel',$tel)->first();
        $id = $use['u_id'];
        $where=[
            'user_id'=>$id,
            'status'=>1
        ];
        $arr = Car::where($where)->join('shop_goods','car.goods_id','=','shop_goods.goods_id')->get();
        $goods = Goods::paginate(4);
        return view('shop/shopcart',['arr'=>$arr,'goods'=>$goods]);
    }

    public function parse(Request $request){
        $id = $request->input('id');
        $ads = $request->input('ads');
        $goods_id = $request->input('goods');
        $az = Goods::where('goods_id',$goods_id)->first();
        if($ads>$az['goods_number']){
            $az = Goods::where('goods_id',$goods_id)->first()->toArray();
            $a = Car::where('car_id',$id)->update(['goods_num'=>$az['goods_number']]);
            $error=[
                'status'=>2,
                'msg'=>'已超过最大库存上限',
                'num'=>$az['goods_number']
            ];
            return $error;
        }else{
            $da = ['goods_num'=>$ads];
            $res = Car::where('car_id',$id)->update($da);
            if($res){
                $error=[
                    'status'=>1,
                    'msg'=>'修改成功'
                ];
                return $error;
            }else{
                $error=[
                    'status'=>0,
                    'msg'=>'修改失败'
                ];
                return $error;
            }
        }
        
    }


    public function dele(Request $request){
        $id = $request->input('snk');
        if($id!=''){
            $res = Car::whereIn('car_id',$id)->update(['status'=>0]);
            if($res){
                return 1;
            }else{
                return 0;
            }
        }
    }


    public function adc(Request $request){
        $data= $request->input();
        $where=[
                'car_id'=>$data['id']
            ];
        if(is_numeric($data['num'])){
            $arr = Car::where($where)->join('shop_goods','car.goods_id','=','shop_goods.goods_id')->first()->toArray();
            if($data['num']>0){
            
            if(intval($data['num'])>=$arr['goods_number']){
                $res = Car::where($where)->update(['goods_num'=>$arr['goods_number']]);
                $error=[
                    'num'=>$arr['goods_number'],
                    'status'=>1
                ];
                return $error;
            }else{
                $res = Car::where($where)->update(['goods_num'=>$data['num']]);
                $error=[
                    'num'=>$data['num'],
                    'status'=>1
                ];
                return $error;
            }
        }else{
              $res = Car::where($where)->update(['goods_num'=>1]);
                $error = [
                    'num'=>1,
                    'status'=>1
                ];
                return $error;
        }

             
              
            
        }else{
                $res = Car::where($where)->update(['goods_num'=>1]);
                $error = [
                    'num'=>1,
                    'status'=>1
                ];
                return $error;
        }
        
    }

    public function back(Request $request){
            $data = $request->input('snk');
            $ads = session('tel');
            if(!empty($ads)){
                 $res = Car::whereIn('car_id',$data)->join('shop_goods','car.goods_id','=','shop_goods.goods_id')->get()->toArray();
                    foreach($res as $v){
                        if($v['goods_num']>$v['goods_number']){
                            $error=[
                                'status'=>2,
                                'msg'=>'抱歉该商品库存不足'
                            ];
                            return $error;
                        }else{
                            $error=[
                                'status'=>0,
                                'msg'=>''
                            ];
                            return $error;
                        }
                    }
                        
            }else{
                $error=[
                    'status'=>1,
                    'msg'=>'请登录后再进入订单'
                ];
                return $error;
            }
    }

    public function payment(Request $request){
        $data = $request->input('id');
        $tel = session('tel');

        $as = User::where('tel',$tel)->first()->toArray();
        $uid = $as['u_id'];
        $wheres = [
            'user_id'=>$uid,
            'sta'=>0
        ];
        $asbdk = Address::where($wheres)->get();
        $order_sn = date("YmdHis",time()).rand(10000,99999);
        $data = explode(',', $data);
        $arr = Car::whereIn('car_id',$data)->join('shop_goods','car.goods_id','=','shop_goods.goods_id')->get();
        $many = [];
        foreach($arr as $v){
            array_push($many,$v['goods_num']*$v['shop_price']);
        }
        $my = array_sum($many);

        $date = [
            'order_sn'=>$order_sn,
            'u_id'=>$uid,
            'order_amount'=>$my
        ];
        $res = order::insertGetId($date);
        if(is_numeric($res)){
            $up = [
                'status'=>2
            ];
            $ask = Car::whereIn('car_id',$data)->update($up);
            $this->payid($res,$data,$uid,$order_sn);
        }
            $asp = count($asbdk);
        if(!empty($asbdk)){
             return view('shop/payment',['arr'=>$arr,'my'=>$my,'order_id'=>$res,'asbdk'=>$asbdk,'asp'=>$asp]);
        }else{
            $asbdk=[];
            return view('shop/payment',['arr'=>$arr,'my'=>$my,'order_id'=>$res,'asbdk'=>$asbdk,'asp'=>$asp]);
        }
       
    }

    public function payid($id,$data,$uid,$order_sn){
        $ascd = Car::whereIn('car_id',$data)->join('shop_goods','car.goods_id','=','shop_goods.goods_id')->get()->toArray();
        foreach($ascd as $v){
            $datra = [
                'order_id'=>$id,
                'user_id'=>$uid,
                'goods_id'=>$v['goods_id'],
                'buy_number'=>$v['goods_num'],
                'goods_name'=>$v['goods_name'],
                'goods_price'=>$v['shop_price'],
                'status'=>2,
                'order_on'=>$order_sn
           ];
           $res = Detail::insert($datra);
        }
       
    }

    public function ent(Request $request){
        $id = $request->input('id');
        $tel = session('tel');
        $as = User::where('tel',$tel)->first()->toArray();
        $uid = $as['u_id'];
        $arg = Goods::where('goods_id',$id)->first()->toArray();
        $where = [
                'user_id'=>$uid,
                'goods_id'=>$id,
                'status'=>1
            ];
        $car = Car::where($where)->first();
        if(!empty($car)){
            if($arg['goods_number']>$car['goods_num']){
            $data = [
                'goods_id'=>$id,
                'user_id'=>$uid,
                'goods_num'=>$car['goods_num']+1,
                'goods_name'=>$arg['goods_name'],
                'status'=>1
            ];
            Car::where($where)->update($data);
            return 1;
        }
        }else{
            if($arg['goods_number']>1){
                $data = [
                    'goods_id'=>$id,
                    'user_id'=>$uid,
                    'goods_num'=>1,
                    'goods_name'=>$arg['goods_name'],
                    'status'=>1
                ];
                Car::insert($data);
                return 1;
            }

        }
    }

    public function shift(Request $request){
        
        $data = $request->input();
        
        $tel = session('tel');
        $as = User::where('tel',$tel)->first()->toArray();
        $uid = $as['u_id'];
        $id = $data['id'];
     //  var_dump($data);die;
        $c=count($data);
        if($c>2){
            //echo 1;
            $dat = array_pop($data);
            //var_dump($data);die;
            $data['user_id']=$uid;
            $data['sta']=0;
            $res = Address::insertGetId($data);
            $pgdn = [
                'address_id'=>$res,
                'order_id'=>$id,
            ];

            $qw = Address_order::insert($pgdn);
            return 1;
        }else{
            
            $pgdn = [
                'address_id'=>$data['address_id'],
                'order_id'=>$id
            ];
            $qw = Address_order::insertGetId($pgdn);
            return 0;
        }
        

    }



    public function userpage(){
        $tel = session('tel');
        return view('shop/userpage',['tel'=>$tel]);

    }

    public function address(){
        $tel = session('tel');
        $as = User::where('tel',$tel)->first()->toArray();
        $uid = $as['u_id'];
        $where = [
            'user_id'=>$uid,
            'sta'=>0
        ];
        $arr = Address::where($where)->get();
        return view('shop/address',['arr'=>$arr]);
    }

    /*
    地址删除
     */
    public function delec(Request $request){
        $id = $request->input('id');
        $data = [
            'sta'=>1
        ];
        $res = Address::where('address_id',$id)->update($data);
        if($res){
            return 1;
        }else{
            return 2;
        }
    }

    /*
    默认地址修改
     */
    public function alerte(Request $request){
        $id = $request->input('id');
        $w = [
            'status'=>1
        ];
        $tel = session('tel');
        $as = User::where('tel',$tel)->first()->toArray();
        $uid = $as['u_id'];
        $h = [
            'status'=>0
        ];
        Address::where('user_id',$uid)->update($h);
        $res = Address::where('address_id',$id)->update($w);
        if($res){
            return 1;
        }else{
            return 0;
        }
    }


    /*
    地址管理修改
     */
    
    public function add(Request $request){
            $id = $request->input();
            $arr = Address::where('address_id',$id)->first();
            return view('shop/writeadd',['arr'=>$arr]);
    }


    public function she(Request $request){
            $data = $request->input();
            //var_dump($data);die;
            $id = $data['address_id'];

            $res = Address::where('address_id',$id)->update($data);
            if($res){
                return 1;
            }else{
                return 0;
            }
    }


    public function write(){
        return view('shop/write');
    }

    public function home(Request $request){
        $data = $request->input();
        $tel = session('tel');
        $as = User::where('tel',$tel)->first()->toArray();
        $uid = $as['u_id'];
        $data['user_id']=$uid;
        $data['sta']=0;
        $res = Address::insert($data);
        if($res){
            return 1;
        }else{
            return 0;
        }
    }

    public function checklogin(){
        $tel = session('tel');
         if(!empty($tel)){
            $error = [
                'status'=>1,
                'msg'=>''
            ];
            return $error;
         }else{
            $error = [
                'status'=>0,
                'msg'=>'请登录后在访问'
            ];
            return $error;
         }
    }

    public function buyrecord(){
                $tel = session('tel');
                $as = User::where('tel',$tel)->first()->toArray();
                $uid = $as['u_id'];
                $arr = order::where('order.u_id',$uid)->join('user','order.u_id','=','user.u_id')->get();
                if(empty($arr)){
                     return view('shop/buyrecord',['arr'=>$arr,'status'=>1]);
                }
                    return view('shop/buyrecord',['arr'=>$arr,'status'=>0]);
    }
    // public function test($daat,$id){
    // 	static $arr = array();
    // 	if(!empty($daat)){
    // 		foreach($daat as $k=>$v){
    // 			if($v['parend_id']==$id){
    // 				$arr[$k] = $v['cate_id'];
    // 				$this->test($daat,$v['cate_id']);
    // 			}
    // 		}
    // 		return $arr;
    // 	}
    // }
}
