<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\User;
use Illuminate\Support\Facades\DB;

class Registercontroller extends Controller
{
    public function register(){
    	return view('register');
    }

    public function registerall(Request $request){

    	$arr = $request->input();

    	$bol = User::where('tel','=',$arr['tel'])->first();
        if(strlen($arr['tel'])!=11){
            $error=[
                    'status'=>1,
                    'msg'=>'手机号错误',
                ];
            return $error;
        }
    	if($arr['pwd']!=$arr['conpwd']){
    			$error=[
    				'status'=>1,
    				'msg'=>'密码不同',
    			];
    			return $error;
    	}else{
	    	if(!empty($bol)){
	    		$error=[
	    			'status'=>1,
	    			'msg'=>'电话号码已存在',
	    		];
	    		return $error;
	    	} else{
	    		$pwd=md5($arr['pwd']);
	    		//$res = User::create($arr);
	    		
	    			$error=[
	    				'status'=>0,
	    				'msg'=>'注册成功',
	    				
	    			];
	    			return $error;
	    		
	    	}
    	}
    }

    public function login(){
    	return view('login');
    }

    public function doadd(Request $request){
    	$arr = $request->input();
    	$tab = User::where('tel','=',$arr['tel'])->first();
    	if(!empty($tab)){
    		if(md5($arr['pwd'])==$tab['pwd']){
                //var_dump($arr);die;
                session($arr);
    			$error=[
    				'status'=>0,
    				'msg'=>'登录成功'
    			];
    			return $error;
    		}else{
    			//var_dump($tab['pwd']);
    			$error=[
    				'status'=>1,
    				'msg'=>'密码错误'
    			];
    			return $error;
    		}
    	}else{
    		$error=[
    			'status'=>1,
    			'msg'=>'用户不存在'
    		];
    		return $error;
    	}
    }

    public function reauth(Request $request){
    	$tel = $request->input('tel');
    	$pwd = $request->input('pwd');
    	//var_dump($arr);die;
    	$top = substr($tel,0,3);
    	$met = substr($tel,7,4);
    	return view('reauth',['top'=>$top,'met'=>$met,'tel'=>$tel,'pwd'=>$pwd]);
    }

    public function tabs(Request $request){
    	$tel = $request->input('tel');
    	//echo $tel;
    	$num = rand(1000,9999);
    	$time=time()+60;
    	$obj = new \send();
    	$res = $obj->show($tel,$num);

    	if($res==100){
    		$data=array(
    			'tel'=>$tel,
    			'num'=>$num,
    			'timeout'=>$time,
    			'code'=>1
    		);
    		$snk = DB::table('code')->insert($data);

    		if($snk){
    			return 1;
    		}else{
    			return 0;
    		}
    	}else{
    		
    		return 0;
    	}
    }

    public function fn(Request $request){
    	$tel = $request->input('tel');
    	$num = $request->input('num');
    	$pwd = $request->input('pwd');
    	$pwd = md5($pwd);
    	$arr=[
    		'tel'=>$tel,
    		'pwd'=>$pwd
    	];
    	$time = time();
    	$sql="select *from code where tel=$tel and num=$num and $time<timeout  and code=1";
    	$res = DB::select($sql);
    	if(!empty($res)){
    		
	    		$res = User::create($arr);
	    		if($res){
	    			return 1;
	    		}else{
	    			return 0;
	    		}
	    			
    	}else{
    		return 0;
    	}
	}
	    		
    

}
