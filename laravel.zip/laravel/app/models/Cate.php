<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Cate extends Model
{
     	protected $table = 'shop_cate';//表名
	    protected $primaryKey = 'cate_id';//主键
	    protected $fillable = ['cate_name'];//允许批量添加的字段
	    public $timestamps = false;//阻止添加时间戳
}
