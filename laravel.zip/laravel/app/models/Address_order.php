<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Address_order extends Model
{
    	protected $table = 'address_order';//表名
	    protected $primaryKey = 'ao_id';//主键
	    
	    public $timestamps = false;//阻止添加时间戳
}
