<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class order extends Model
{
    protected $table = 'order';//表名
    protected $primaryKey = 'order_id';//主键
    public $timestamps = false;//阻止添加时间戳
}
