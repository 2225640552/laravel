<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    	protected $table = 'address';//表名
	    protected $primaryKey = 'address_id';//主键
	    
	    public $timestamps = false;//阻止添加时间戳
}
