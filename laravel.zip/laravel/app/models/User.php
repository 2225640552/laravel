<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $table = 'user';//表名
    protected $primaryKey = 'u_id';//主键
    protected $fillable = ['tel','pwd'];//允许批量添加的字段
    public $timestamps = false;//阻止添加时间戳
}
