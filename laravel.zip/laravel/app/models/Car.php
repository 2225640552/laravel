<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
    	protected $table = 'car';//表名
	    protected $primaryKey = 'car_id';//主键
	    
	    public $timestamps = false;//阻止添加时间戳
}
