<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Goods extends Model
{
    protected $table = 'shop_goods';//表名
    protected $primaryKey = 'goods_id';//主键
    protected $fillable = ['goods_name','goods_cate','goods_count','is_hot','is_ja'];//允许批量添加的字段
    public $timestamps = false;//阻止添加时间戳
}
