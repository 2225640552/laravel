<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Detail extends Model
{
    protected $table = 'shop_order_detail';//表名
    protected $primaryKey = 'id';//主键
    public $timestamps = false;//阻止添加时间戳
}
