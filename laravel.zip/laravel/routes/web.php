<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// Route::get('show/{id?}',function($id){
// 	echo $id;
// });

Route::get('admin','Admin@index');
Route::post('save','Admin@save');
Route::any('create','Admin@create');
Route::post('delete','Admin@delete');  
Route::post('ajd','Admin@ajd');
Route::post('skr','Admin@skr');
Route::get('read','Admin@read');
Route::post('caps','Admin@caps');
Route::post('tab','Admin@tab');
Route::post('alt','Admin@alt');



Route::get('index','Indexcontroller@index');
Route::get('register','Registercontroller@register');
Route::get('login','Registercontroller@login');
Route::get('user','Indexcontroller@user');
Route::post('registerall','Registercontroller@registerall');
Route::post('doadd','Registercontroller@doadd');
Route::any('reauth','Registercontroller@reauth');
Route::any('tabs','Registercontroller@tabs');
Route::any('fn','Registercontroller@fn');
Route::any('pgup','Indexcontroller@pgup');
Route::any('allshops','Indexcontroller@allshops');
Route::any('shi','Indexcontroller@shi');
Route::any('shopcontent','Indexcontroller@shopcontent');
Route::post('content','Indexcontroller@content');
Route::any('shopcart','Indexcontroller@shopcart');
Route::any('shopse','Indexcontroller@shopse');
Route::any('parse','Indexcontroller@parse');
Route::post('dele','Indexcontroller@dele');
Route::post('adc','Indexcontroller@adc');
Route::post('back','Indexcontroller@back');
Route::get('payment','Indexcontroller@payment');
Route::post('ent','Indexcontroller@ent');
Route::post('shift','Indexcontroller@shift');
Route::get('userpage','Indexcontroller@userpage');
Route::get('address','Indexcontroller@address');
Route::post('delec','Indexcontroller@delec');
Route::post('alerte','Indexcontroller@alerte');
Route::get('add','Indexcontroller@add');
Route::post('she','Indexcontroller@she');
Route::post('home','Indexcontroller@home');
Route::get('write','Indexcontroller@write');
Route::get('buyrecord','Indexcontroller@buyrecord');
Route::post('checklogin','Indexcontroller@checklogin');