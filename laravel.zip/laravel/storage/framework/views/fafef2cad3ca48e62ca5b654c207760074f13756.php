<!DOCTYPE html>
<html lang="en">
<head>
	<script src="/js/jquery-3.1.1.min.js"></script>
	<meta charset="UTF-8">
	<title>添加</title>
</head>
<body>
	<form action="caps" method="post">
		<input type="hidden" value="<?php echo e($arr->goods_id); ?>" name="goods_id">
		<table>
			<tr>
				<td>名称</td>
				<td><input type="text" name="goods_name" value="<?php echo e($arr->goods_name); ?>"></td>
			</tr>
			<tr>
				<td>分类</td>
				<td>
					<select name="goods_cate" id="">
						<?php $__currentLoopData = $arrCate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
							<option <?php if($arr->goods_cate==$v->cate_id): ?> selected <?php endif; ?> value="<?php echo e($v->cate_id); ?>"><?php echo e($v->cate_name); ?></option>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>描述</td>
				<td><textarea name="goods_count" id="" cols="30" rows="10"><?php echo e($arr->goods_count); ?></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="确定" ></td>
			</tr>
		</table>
	</form>
</body>
</html>